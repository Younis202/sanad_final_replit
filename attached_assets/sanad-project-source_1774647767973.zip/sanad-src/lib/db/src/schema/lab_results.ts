import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const labResultsTable = pgTable("lab_results", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  testName: text("test_name").notNull(),
  testNameAr: text("test_name_ar"),
  value: text("value").notNull(),
  unit: text("unit"),
  normalRange: text("normal_range"),
  status: text("status").notNull().default("normal"),
  testedAt: text("tested_at").notNull(),
  hospital: text("hospital"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertLabResultSchema = createInsertSchema(labResultsTable).omit({ id: true, createdAt: true });
export type InsertLabResult = z.infer<typeof insertLabResultSchema>;
export type LabResult = typeof labResultsTable.$inferSelect;
