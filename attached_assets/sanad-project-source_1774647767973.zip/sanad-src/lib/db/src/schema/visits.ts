import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const visitsTable = pgTable("visits", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  hospital: text("hospital").notNull(),
  department: text("department"),
  diagnosis: text("diagnosis").notNull(),
  diagnosisAr: text("diagnosis_ar"),
  doctorName: text("doctor_name"),
  visitDate: text("visit_date").notNull(),
  notes: text("notes"),
  visitType: text("visit_type").notNull().default("outpatient"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertVisitSchema = createInsertSchema(visitsTable).omit({ id: true, createdAt: true });
export type InsertVisit = z.infer<typeof insertVisitSchema>;
export type Visit = typeof visitsTable.$inferSelect;
