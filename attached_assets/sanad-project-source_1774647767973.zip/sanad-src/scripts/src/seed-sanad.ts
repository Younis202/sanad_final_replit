import { db, patientsTable, medicationsTable, labResultsTable, visitsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("🌱 Seeding Sanad database...");

  // Clear existing data
  await db.delete(visitsTable);
  await db.delete(labResultsTable);
  await db.delete(medicationsTable);
  await db.delete(patientsTable);

  // Insert demo patients
  const [p1] = await db.insert(patientsTable).values({
    nationalId: "1234567890",
    nameAr: "محمد أحمد الزهراني",
    nameEn: "Mohammed Ahmed Al-Zahrani",
    bloodType: "A+",
    dateOfBirth: "1975-06-15",
    gender: "male",
    phone: "0501234567",
    allergies: ["بنسلين", "سلفا", "Penicillin"],
    chronicDiseases: ["سكري النوع الثاني", "ضغط الدم"],
    emergencyContact: "فاطمة الزهراني",
    emergencyPhone: "0507654321",
  }).returning();

  const [p2] = await db.insert(patientsTable).values({
    nationalId: "9876543210",
    nameAr: "سارة عبدالله الحربي",
    nameEn: "Sara Abdullah Al-Harbi",
    bloodType: "O+",
    dateOfBirth: "1988-03-22",
    gender: "female",
    phone: "0556789012",
    allergies: ["مضادات الالتهاب"],
    chronicDiseases: ["ربو"],
    emergencyContact: "عبدالله الحربي",
    emergencyPhone: "0551234567",
  }).returning();

  const [p3] = await db.insert(patientsTable).values({
    nationalId: "5555555555",
    nameAr: "خالد محمد العتيبي",
    nameEn: "Khalid Mohammed Al-Otaibi",
    bloodType: "B-",
    dateOfBirth: "1962-11-08",
    gender: "male",
    phone: "0509876543",
    allergies: ["لاتكس", "كودين"],
    chronicDiseases: ["أمراض القلب التاجية", "سكري النوع الثاني", "ضغط الدم", "ارتفاع الكوليسترول"],
    emergencyContact: "نورة العتيبي",
    emergencyPhone: "0503456789",
  }).returning();

  console.log(`✅ Created ${3} patients`);

  // Medications for patient 1
  await db.insert(medicationsTable).values([
    {
      patientId: p1.id,
      name: "Metformin",
      nameAr: "ميتفورمين",
      dosage: "500mg",
      frequency: "مرتين يومياً",
      prescribedBy: "د. عبدالرحمن السيد",
      hospital: "مستشفى الملك فهد",
      startDate: "2023-01-15",
      isActive: true,
      category: "antidiabetic",
    },
    {
      patientId: p1.id,
      name: "Lisinopril",
      nameAr: "ليسينوبريل",
      dosage: "10mg",
      frequency: "مرة يومياً",
      prescribedBy: "د. سمر الأحمدي",
      hospital: "مستشفى الملك فهد",
      startDate: "2022-08-20",
      isActive: true,
      category: "antihypertensive",
    },
    {
      patientId: p1.id,
      name: "Aspirin",
      nameAr: "أسبرين",
      dosage: "81mg",
      frequency: "مرة يومياً",
      prescribedBy: "د. عبدالرحمن السيد",
      hospital: "مستشفى التخصصي",
      startDate: "2023-05-10",
      isActive: true,
      category: "antiplatelet",
    },
  ]);

  // Medications for patient 2
  await db.insert(medicationsTable).values([
    {
      patientId: p2.id,
      name: "Salbutamol Inhaler",
      nameAr: "بخاخ سالبوتامول",
      dosage: "100mcg",
      frequency: "عند الحاجة",
      prescribedBy: "د. نادية حسن",
      hospital: "مستشفى الأمير سلطان",
      startDate: "2021-09-01",
      isActive: true,
      category: "bronchodilator",
    },
    {
      patientId: p2.id,
      name: "Fluticasone Inhaler",
      nameAr: "بخاخ فلوتيكازون",
      dosage: "250mcg",
      frequency: "مرتين يومياً",
      prescribedBy: "د. نادية حسن",
      hospital: "مستشفى الأمير سلطان",
      startDate: "2021-09-01",
      isActive: true,
      category: "corticosteroid",
    },
  ]);

  // Medications for patient 3
  await db.insert(medicationsTable).values([
    {
      patientId: p3.id,
      name: "Warfarin",
      nameAr: "وارفارين",
      dosage: "5mg",
      frequency: "مرة يومياً",
      prescribedBy: "د. طارق القحطاني",
      hospital: "مستشفى الملك عبدالعزيز",
      startDate: "2020-03-15",
      isActive: true,
      category: "anticoagulant",
    },
    {
      patientId: p3.id,
      name: "Simvastatin",
      nameAr: "سيمفاستاتين",
      dosage: "40mg",
      frequency: "مرة يومياً مساءً",
      prescribedBy: "د. طارق القحطاني",
      hospital: "مستشفى الملك عبدالعزيز",
      startDate: "2020-03-15",
      isActive: true,
      category: "statin",
    },
    {
      patientId: p3.id,
      name: "Metformin",
      nameAr: "ميتفورمين",
      dosage: "1000mg",
      frequency: "مرتين يومياً",
      prescribedBy: "د. هند المالكي",
      hospital: "عيادة الصحة للجميع",
      startDate: "2019-07-20",
      isActive: true,
      category: "antidiabetic",
    },
    {
      patientId: p3.id,
      name: "Aspirin",
      nameAr: "أسبرين",
      dosage: "100mg",
      frequency: "مرة يومياً",
      prescribedBy: "د. طارق القحطاني",
      hospital: "مستشفى الملك عبدالعزيز",
      startDate: "2020-03-15",
      isActive: true,
      category: "antiplatelet",
    },
  ]);

  console.log("✅ Created medications");

  // Lab results for patient 1
  await db.insert(labResultsTable).values([
    {
      patientId: p1.id,
      testName: "HbA1c",
      testNameAr: "الهيموجلوبين السكري",
      value: "7.8",
      unit: "%",
      normalRange: "4.0 - 5.6",
      status: "high",
      testedAt: "2024-11-15",
      hospital: "مستشفى الملك فهد",
    },
    {
      patientId: p1.id,
      testName: "Fasting Blood Glucose",
      testNameAr: "سكر الدم الصائم",
      value: "145",
      unit: "mg/dL",
      normalRange: "70 - 100",
      status: "high",
      testedAt: "2024-11-15",
      hospital: "مستشفى الملك فهد",
    },
    {
      patientId: p1.id,
      testName: "Blood Pressure",
      testNameAr: "ضغط الدم",
      value: "138/88",
      unit: "mmHg",
      normalRange: "< 120/80",
      status: "high",
      testedAt: "2024-12-01",
      hospital: "مستشفى الملك فهد",
    },
    {
      patientId: p1.id,
      testName: "Creatinine",
      testNameAr: "كرياتينين",
      value: "0.9",
      unit: "mg/dL",
      normalRange: "0.7 - 1.2",
      status: "normal",
      testedAt: "2024-11-15",
      hospital: "مستشفى الملك فهد",
    },
  ]);

  // Lab results for patient 3 (more critical)
  await db.insert(labResultsTable).values([
    {
      patientId: p3.id,
      testName: "INR",
      testNameAr: "نسبة التخثر",
      value: "3.8",
      unit: "",
      normalRange: "2.0 - 3.0",
      status: "critical",
      testedAt: "2024-12-20",
      hospital: "مستشفى الملك عبدالعزيز",
    },
    {
      patientId: p3.id,
      testName: "LDL Cholesterol",
      testNameAr: "الكوليسترول الضار",
      value: "178",
      unit: "mg/dL",
      normalRange: "< 100",
      status: "high",
      testedAt: "2024-12-20",
      hospital: "مستشفى الملك عبدالعزيز",
    },
    {
      patientId: p3.id,
      testName: "HbA1c",
      testNameAr: "الهيموجلوبين السكري",
      value: "9.1",
      unit: "%",
      normalRange: "4.0 - 5.6",
      status: "critical",
      testedAt: "2024-12-20",
      hospital: "مستشفى الملك عبدالعزيز",
    },
  ]);

  console.log("✅ Created lab results");

  // Visits for patient 1
  await db.insert(visitsTable).values([
    {
      patientId: p1.id,
      hospital: "مستشفى الملك فهد",
      department: "الباطنة",
      diagnosis: "Type 2 Diabetes - Follow-up",
      diagnosisAr: "متابعة سكري النوع الثاني",
      doctorName: "د. عبدالرحمن السيد",
      visitDate: "2024-11-15",
      visitType: "follow-up",
      notes: "ضبط الجرعة - HbA1c مرتفع قليلاً",
    },
    {
      patientId: p1.id,
      hospital: "مستشفى التخصصي",
      department: "القلب",
      diagnosis: "Hypertension Management",
      diagnosisAr: "إدارة ضغط الدم",
      doctorName: "د. سمر الأحمدي",
      visitDate: "2024-09-03",
      visitType: "outpatient",
      notes: "مستقر - يكمل العلاج",
    },
    {
      patientId: p1.id,
      hospital: "مستشفى الملك فهد",
      department: "الطوارئ",
      diagnosis: "Hypoglycemia Episode",
      diagnosisAr: "نوبة انخفاض سكر الدم",
      doctorName: "د. ريم الشمري",
      visitDate: "2024-07-18",
      visitType: "emergency",
      notes: "جاء بإغماء - أُعطي محلول جلوكوز - تعافى",
    },
  ]);

  // Visits for patient 3
  await db.insert(visitsTable).values([
    {
      patientId: p3.id,
      hospital: "مستشفى الملك عبدالعزيز",
      department: "القلب",
      diagnosis: "Coronary Artery Disease - Monitoring",
      diagnosisAr: "متابعة أمراض القلب التاجية",
      doctorName: "د. طارق القحطاني",
      visitDate: "2024-12-20",
      visitType: "follow-up",
      notes: "INR مرتفع - تعديل جرعة الوارفارين مطلوب",
    },
    {
      patientId: p3.id,
      hospital: "مستشفى الملك عبدالعزيز",
      department: "الطوارئ",
      diagnosis: "Chest Pain Investigation",
      diagnosisAr: "فحص ألم الصدر",
      doctorName: "د. هناء السلمي",
      visitDate: "2024-10-05",
      visitType: "emergency",
      notes: "ألم صدر حاد - ECG طبيعي - حجز للمراقبة",
    },
  ]);

  console.log("✅ Created visits");
  console.log("🎉 Sanad database seeded successfully!");
  console.log(`
Demo Patients:
  - محمد أحمد الزهراني → National ID: 1234567890
  - سارة عبدالله الحربي → National ID: 9876543210
  - خالد محمد العتيبي  → National ID: 5555555555 (HIGH RISK - multiple interactions)
  `);
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
