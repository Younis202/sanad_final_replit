import { Router, type IRouter } from "express";
import healthRouter from "./health";
import patientsRouter from "./patients";
import emergencyRouter from "./emergency";
import doctorRouter from "./doctor";
import medicationsRouter from "./medications";
import aiRouter from "./ai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(patientsRouter);
router.use(emergencyRouter);
router.use(doctorRouter);
router.use(medicationsRouter);
router.use(aiRouter);

export default router;
