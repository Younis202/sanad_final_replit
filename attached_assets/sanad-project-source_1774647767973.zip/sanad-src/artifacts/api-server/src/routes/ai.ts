import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, patientsTable, labResultsTable } from "@workspace/db";
import {
  CheckDrugInteractionBody,
  CheckDrugInteractionResponse,
  GetPatientRiskScoreParams,
  GetPatientRiskScoreResponse,
} from "@workspace/api-zod";
import { analyzeRiskScore, checkInteractionsForDrug } from "../lib/ai-engine.js";

const router: IRouter = Router();

router.post("/ai/drug-interaction", async (req, res): Promise<void> => {
  const parsed = CheckDrugInteractionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { newDrugName, currentMedications } = parsed.data;
  const result = checkInteractionsForDrug(newDrugName, currentMedications);

  res.json(CheckDrugInteractionResponse.parse(result));
});

router.get("/ai/risk-score/:patientId", async (req, res): Promise<void> => {
  const params = GetPatientRiskScoreParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [patient] = await db.select().from(patientsTable).where(eq(patientsTable.id, params.data.patientId));
  if (!patient) {
    res.status(404).json({ error: "Patient not found" });
    return;
  }

  const labResults = await db.select().from(labResultsTable).where(eq(labResultsTable.patientId, params.data.patientId));
  const riskScore = analyzeRiskScore(patient, labResults);

  res.json(GetPatientRiskScoreResponse.parse({
    patientId: params.data.patientId,
    ...riskScore,
  }));
});

export default router;
