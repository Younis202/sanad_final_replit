import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, patientsTable, medicationsTable } from "@workspace/db";
import { EmergencyScanResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/emergency/scan/:nationalId", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.nationalId) ? req.params.nationalId[0] : req.params.nationalId;

  const [patient] = await db
    .select()
    .from(patientsTable)
    .where(eq(patientsTable.nationalId, raw));

  if (!patient) {
    res.status(404).json({ error: "Patient not found" });
    return;
  }

  const medications = await db
    .select()
    .from(medicationsTable)
    .where(eq(medicationsTable.patientId, patient.id));

  const activeMeds = medications.filter(m => m.isActive);

  const criticalAlerts: string[] = [];

  if ((patient.allergies ?? []).length > 0) {
    criticalAlerts.push(`⚠️ حساسية: ${(patient.allergies ?? []).join(", ")}`);
  }
  if ((patient.chronicDiseases ?? []).length > 0) {
    criticalAlerts.push(`🏥 أمراض مزمنة: ${(patient.chronicDiseases ?? []).join(", ")}`);
  }
  if (activeMeds.length > 0) {
    criticalAlerts.push(`💊 يأخذ ${activeMeds.length} دواء نشط`);
  }

  res.json(EmergencyScanResponse.parse({
    patient: {
      ...patient,
      allergies: patient.allergies ?? [],
      chronicDiseases: patient.chronicDiseases ?? [],
      createdAt: patient.createdAt?.toISOString(),
    },
    criticalAlerts,
    activeMedications: activeMeds.map(m => ({
      ...m,
      createdAt: undefined,
      nameAr: m.nameAr ?? undefined,
      prescribedBy: m.prescribedBy ?? undefined,
      hospital: m.hospital ?? undefined,
      startDate: m.startDate ?? undefined,
      endDate: m.endDate ?? undefined,
      category: m.category ?? undefined,
    })),
    scanTime: new Date().toISOString(),
  }));
});

export default router;
