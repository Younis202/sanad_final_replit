import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, patientsTable, medicationsTable, labResultsTable, visitsTable } from "@workspace/db";
import { GetDoctorPatientViewResponse } from "@workspace/api-zod";
import { analyzeRiskScore, checkInteractions } from "../lib/ai-engine.js";

const router: IRouter = Router();

router.get("/doctor/patient/:nationalId", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.nationalId) ? req.params.nationalId[0] : req.params.nationalId;

  const [patient] = await db
    .select()
    .from(patientsTable)
    .where(eq(patientsTable.nationalId, raw));

  if (!patient) {
    res.status(404).json({ error: "Patient not found" });
    return;
  }

  const [medications, labResults, visits] = await Promise.all([
    db.select().from(medicationsTable).where(eq(medicationsTable.patientId, patient.id)),
    db.select().from(labResultsTable).where(eq(labResultsTable.patientId, patient.id)).orderBy(labResultsTable.testedAt),
    db.select().from(visitsTable).where(eq(visitsTable.patientId, patient.id)).orderBy(visitsTable.visitDate),
  ]);

  const activeMeds = medications.filter(m => m.isActive).map(m => m.name);
  const riskScore = analyzeRiskScore(patient, labResults);
  const interactions = checkInteractions(activeMeds);

  res.json(GetDoctorPatientViewResponse.parse({
    patient: {
      ...patient,
      allergies: patient.allergies ?? [],
      chronicDiseases: patient.chronicDiseases ?? [],
      createdAt: patient.createdAt?.toISOString(),
    },
    medications: medications.map(m => ({
      ...m,
      createdAt: undefined,
      nameAr: m.nameAr ?? undefined,
      prescribedBy: m.prescribedBy ?? undefined,
      hospital: m.hospital ?? undefined,
      startDate: m.startDate ?? undefined,
      endDate: m.endDate ?? undefined,
      category: m.category ?? undefined,
    })),
    labResults: labResults.map(l => ({
      ...l,
      createdAt: undefined,
      testNameAr: l.testNameAr ?? undefined,
      unit: l.unit ?? undefined,
      normalRange: l.normalRange ?? undefined,
      hospital: l.hospital ?? undefined,
    })),
    visits: visits.map(v => ({
      ...v,
      createdAt: undefined,
      department: v.department ?? undefined,
      diagnosisAr: v.diagnosisAr ?? undefined,
      doctorName: v.doctorName ?? undefined,
      notes: v.notes ?? undefined,
    })),
    riskScore,
    drugInteractions: interactions,
  }));
});

export default router;
