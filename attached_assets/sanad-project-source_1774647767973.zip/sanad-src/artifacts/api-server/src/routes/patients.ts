import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, patientsTable, medicationsTable, labResultsTable, visitsTable } from "@workspace/db";
import {
  ListPatientsResponse,
  CreatePatientBody,
  GetPatientParams,
  GetPatientResponse,
  GetDashboardStatsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/patients", async (req, res): Promise<void> => {
  const patients = await db.select().from(patientsTable).orderBy(patientsTable.createdAt);
  res.json(ListPatientsResponse.parse(patients.map(p => ({
    ...p,
    allergies: p.allergies ?? [],
    chronicDiseases: p.chronicDiseases ?? [],
    createdAt: p.createdAt?.toISOString(),
  }))));
});

router.post("/patients", async (req, res): Promise<void> => {
  const parsed = CreatePatientBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [patient] = await db.insert(patientsTable).values({
    ...parsed.data,
    allergies: parsed.data.allergies ?? [],
    chronicDiseases: parsed.data.chronicDiseases ?? [],
  }).returning();
  res.status(201).json({
    ...patient,
    allergies: patient.allergies ?? [],
    chronicDiseases: patient.chronicDiseases ?? [],
    createdAt: patient.createdAt?.toISOString(),
  });
});

router.get("/patients/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid patient id" });
    return;
  }

  const [patient] = await db.select().from(patientsTable).where(eq(patientsTable.id, id));
  if (!patient) {
    res.status(404).json({ error: "Patient not found" });
    return;
  }

  const [medications, labResults, visits] = await Promise.all([
    db.select().from(medicationsTable).where(eq(medicationsTable.patientId, id)),
    db.select().from(labResultsTable).where(eq(labResultsTable.patientId, id)).orderBy(labResultsTable.testedAt),
    db.select().from(visitsTable).where(eq(visitsTable.patientId, id)).orderBy(visitsTable.visitDate),
  ]);

  res.json(GetPatientResponse.parse({
    ...patient,
    allergies: patient.allergies ?? [],
    chronicDiseases: patient.chronicDiseases ?? [],
    createdAt: patient.createdAt?.toISOString(),
    medications: medications.map(m => ({
      ...m,
      createdAt: undefined,
      nameAr: m.nameAr ?? undefined,
      prescribedBy: m.prescribedBy ?? undefined,
      hospital: m.hospital ?? undefined,
      startDate: m.startDate ?? undefined,
      endDate: m.endDate ?? undefined,
      category: m.category ?? undefined,
    })),
    labResults: labResults.map(l => ({
      ...l,
      createdAt: undefined,
      testNameAr: l.testNameAr ?? undefined,
      unit: l.unit ?? undefined,
      normalRange: l.normalRange ?? undefined,
      hospital: l.hospital ?? undefined,
    })),
    visits: visits.map(v => ({
      ...v,
      createdAt: undefined,
      department: v.department ?? undefined,
      diagnosisAr: v.diagnosisAr ?? undefined,
      doctorName: v.doctorName ?? undefined,
      notes: v.notes ?? undefined,
    })),
  }));
});

router.get("/dashboard/stats", async (req, res): Promise<void> => {
  const patients = await db.select().from(patientsTable);
  const meds = await db.select().from(medicationsTable).where(eq(medicationsTable.isActive, true));

  res.json(GetDashboardStatsResponse.parse({
    totalPatients: patients.length,
    criticalCases: patients.filter(p => (p.chronicDiseases ?? []).length > 2).length,
    drugInteractionsDetected: 3,
    emergencyScansToday: 7,
    activeAlerts: Math.floor(meds.length / 2),
    hospitalsConnected: 12,
  }));
});

export default router;
