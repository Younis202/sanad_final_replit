import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, medicationsTable } from "@workspace/db";
import {
  ListMedicationsResponse,
  GetPatientMedicationsParams,
  GetPatientMedicationsResponse,
  AddPatientMedicationParams,
  AddPatientMedicationBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/medications", async (req, res): Promise<void> => {
  const meds = await db.select().from(medicationsTable);
  res.json(ListMedicationsResponse.parse(meds.map(m => ({ ...m, createdAt: undefined }))));
});

router.get("/medications/:patientId", async (req, res): Promise<void> => {
  const params = GetPatientMedicationsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const meds = await db.select().from(medicationsTable).where(eq(medicationsTable.patientId, params.data.patientId));
  res.json(GetPatientMedicationsResponse.parse(meds.map(m => ({ ...m, createdAt: undefined }))));
});

router.post("/medications/:patientId", async (req, res): Promise<void> => {
  const params = AddPatientMedicationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = AddPatientMedicationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [med] = await db.insert(medicationsTable).values({
    ...body.data,
    patientId: params.data.patientId,
    isActive: true,
  }).returning();
  res.status(201).json({ ...med, createdAt: undefined });
});

export default router;
