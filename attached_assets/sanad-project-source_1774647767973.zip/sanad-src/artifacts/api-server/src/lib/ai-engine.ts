import type { Patient } from "@workspace/db";

type LabResult = {
  id: number;
  patientId: number;
  testName: string;
  value: string;
  status: string;
  testedAt: string;
};

const DRUG_INTERACTIONS: Record<string, { interacts_with: string[]; severity: string; description: string; recommendation: string }> = {
  warfarin: {
    interacts_with: ["aspirin", "ibuprofen", "naproxen", "clopidogrel"],
    severity: "critical",
    description: "خطر نزيف حاد - يزيد تأثير مضادات التخثر",
    recommendation: "تجنب الجمع - استشر طبيب أمراض الدم فوراً",
  },
  metformin: {
    interacts_with: ["contrast dye", "alcohol", "iodine"],
    severity: "severe",
    description: "خطر الحماض اللبني",
    recommendation: "أوقف الميتفورمين قبل 48 ساعة من أي صبغة تشخيصية",
  },
  lisinopril: {
    interacts_with: ["potassium", "spironolactone", "nsaids"],
    severity: "moderate",
    description: "قد يرفع البوتاسيوم لمستويات خطيرة",
    recommendation: "راقب مستوى البوتاسيوم بانتظام",
  },
  simvastatin: {
    interacts_with: ["clarithromycin", "erythromycin", "fluconazole", "amiodarone"],
    severity: "severe",
    description: "خطر اعتلال العضلات والفشل الكلوي",
    recommendation: "أوقف السيمفاستاتين أثناء العلاج بالمضاد الحيوي",
  },
  clopidogrel: {
    interacts_with: ["omeprazole", "pantoprazole", "aspirin"],
    severity: "moderate",
    description: "قد يقلل تأثير الكلوبيدوجريل",
    recommendation: "استخدم رابيبرازول بدلاً من أوميبرازول",
  },
};

export function checkInteractionsForDrug(
  newDrug: string,
  currentMeds: string[]
): {
  hasInteraction: boolean;
  severity: "none" | "mild" | "moderate" | "severe" | "critical";
  interactions: Array<{ drug1: string; drug2: string; description: string; recommendation: string }>;
  recommendation: string;
} {
  const newDrugLower = newDrug.toLowerCase();
  const interactions: Array<{ drug1: string; drug2: string; description: string; recommendation: string }> = [];
  let maxSeverity: "none" | "mild" | "moderate" | "severe" | "critical" = "none";

  for (const [drug, info] of Object.entries(DRUG_INTERACTIONS)) {
    const drugMatchesNew = newDrugLower.includes(drug) || drug.includes(newDrugLower);
    const drugMatchesCurrent = currentMeds.some(m => m.toLowerCase().includes(drug) || drug.includes(m.toLowerCase()));

    if (drugMatchesNew) {
      for (const existing of currentMeds) {
        const existingLower = existing.toLowerCase();
        if (info.interacts_with.some(i => existingLower.includes(i) || i.includes(existingLower))) {
          interactions.push({
            drug1: newDrug,
            drug2: existing,
            description: info.description,
            recommendation: info.recommendation,
          });
          if (sevOrder(info.severity as "none" | "mild" | "moderate" | "severe" | "critical") > sevOrder(maxSeverity)) {
            maxSeverity = info.severity as "none" | "mild" | "moderate" | "severe" | "critical";
          }
        }
      }
    }

    if (drugMatchesCurrent) {
      const isNewDrugAnInteractor = info.interacts_with.some(i =>
        newDrugLower.includes(i) || i.includes(newDrugLower)
      );
      if (isNewDrugAnInteractor) {
        const matchingMed = currentMeds.find(m => m.toLowerCase().includes(drug) || drug.includes(m.toLowerCase()));
        if (matchingMed) {
          interactions.push({
            drug1: matchingMed,
            drug2: newDrug,
            description: info.description,
            recommendation: info.recommendation,
          });
          if (sevOrder(info.severity as "none" | "mild" | "moderate" | "severe" | "critical") > sevOrder(maxSeverity)) {
            maxSeverity = info.severity as "none" | "mild" | "moderate" | "severe" | "critical";
          }
        }
      }
    }
  }

  return {
    hasInteraction: interactions.length > 0,
    severity: maxSeverity,
    interactions,
    recommendation: interactions.length > 0
      ? `تحذير: تم اكتشاف ${interactions.length} تفاعل دوائي. يرجى مراجعة الطبيب.`
      : "لا توجد تفاعلات دوائية معروفة. الدواء آمن للوصف.",
  };
}

export function checkInteractions(
  activeMeds: string[]
): Array<{ hasInteraction: boolean; severity: string; interactions: Array<{ drug1: string; drug2: string; description: string; recommendation: string }>; recommendation: string }> {
  const results = [];
  for (let i = 0; i < activeMeds.length; i++) {
    const others = activeMeds.filter((_, idx) => idx !== i);
    const check = checkInteractionsForDrug(activeMeds[i], others);
    if (check.hasInteraction) {
      results.push(check);
    }
  }
  return results;
}

export function analyzeRiskScore(
  patient: Patient,
  labResults: LabResult[]
): {
  overallScore: number;
  riskLevel: "low" | "moderate" | "high" | "critical";
  alerts: Array<{ type: string; message: string; messageAr: string; priority: "info" | "warning" | "danger" }>;
  diabetesRisk: number;
  heartRisk: number;
  kidneyRisk: number;
} {
  const alerts: Array<{ type: string; message: string; messageAr: string; priority: "info" | "warning" | "danger" }> = [];
  let score = 0;
  let diabetesRisk = 10;
  let heartRisk = 10;
  let kidneyRisk = 10;

  const chronicDiseases = patient.chronicDiseases ?? [];
  const allergies = patient.allergies ?? [];

  // Chronic disease scoring
  if (chronicDiseases.some(d => /سكر|diabetes/i.test(d))) {
    score += 25;
    diabetesRisk = 75;
    alerts.push({
      type: "diabetes",
      message: "Patient has diabetes - monitor HbA1c regularly",
      messageAr: "المريض مصاب بالسكري - راقب HbA1c بانتظام",
      priority: "warning",
    });
  }
  if (chronicDiseases.some(d => /ضغط|hypertension/i.test(d))) {
    score += 20;
    heartRisk += 30;
    alerts.push({
      type: "hypertension",
      message: "High blood pressure detected",
      messageAr: "ارتفاع ضغط الدم مسجل",
      priority: "warning",
    });
  }
  if (chronicDiseases.some(d => /قلب|heart|cardiac/i.test(d))) {
    score += 30;
    heartRisk = 80;
    alerts.push({
      type: "cardiac",
      message: "Cardiac condition - immediate attention required",
      messageAr: "حالة قلبية - تتطلب اهتمامًا فوريًا",
      priority: "danger",
    });
  }

  // Lab results scoring
  const criticalLabs = labResults.filter(l => l.status === "critical");
  const highLabs = labResults.filter(l => l.status === "high");
  score += criticalLabs.length * 15;
  score += highLabs.length * 8;

  if (criticalLabs.length > 0) {
    alerts.push({
      type: "lab_critical",
      message: `${criticalLabs.length} critical lab results require attention`,
      messageAr: `${criticalLabs.length} نتائج تحليل حرجة تتطلب اهتمامًا فورياً`,
      priority: "danger",
    });
  }

  // Age-based risk
  const birthYear = parseInt(patient.dateOfBirth?.split("-")[0] ?? "1990");
  const age = new Date().getFullYear() - birthYear;
  if (age > 60) {
    score += 15;
    alerts.push({
      type: "age",
      message: "Senior patient - higher risk profile",
      messageAr: "مريض كبير السن - ملف مخاطر أعلى",
      priority: "info",
    });
  }

  if (allergies.length > 0) {
    alerts.push({
      type: "allergy",
      message: `Known allergies: ${allergies.join(", ")}`,
      messageAr: `حساسيات معروفة: ${allergies.join(", ")}`,
      priority: "warning",
    });
  }

  score = Math.min(100, score);
  const riskLevel: "low" | "moderate" | "high" | "critical" =
    score < 25 ? "low" :
    score < 50 ? "moderate" :
    score < 75 ? "high" : "critical";

  return {
    overallScore: score,
    riskLevel,
    alerts,
    diabetesRisk: Math.min(100, diabetesRisk),
    heartRisk: Math.min(100, heartRisk),
    kidneyRisk: Math.min(100, kidneyRisk),
  };
}

function sevOrder(s: "none" | "mild" | "moderate" | "severe" | "critical"): number {
  return { none: 0, mild: 1, moderate: 2, severe: 3, critical: 4 }[s];
}
