import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Home from "./pages/home";
import EmergencyScan from "./pages/emergency/scan";
import EmergencyResult from "./pages/emergency/result";
import DoctorSearch from "./pages/doctor/search";
import DoctorDashboard from "./pages/doctor/dashboard";
import CitizenDashboard from "./pages/citizen/dashboard";
import AdminDashboard from "./pages/admin/dashboard";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4 text-primary">404</h1>
        <p className="text-muted-foreground text-lg">الصفحة غير موجودة</p>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/emergency" component={EmergencyScan} />
      <Route path="/emergency/:id" component={EmergencyResult} />
      <Route path="/doctor" component={DoctorSearch} />
      <Route path="/doctor/:id" component={DoctorDashboard} />
      <Route path="/citizen" component={CitizenDashboard} />
      <Route path="/admin" component={AdminDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
