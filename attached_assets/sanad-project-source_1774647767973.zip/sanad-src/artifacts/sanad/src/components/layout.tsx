import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { 
  Home, Stethoscope, Siren, UserCircle, ActivitySquare, ShieldPlus, Settings, Bell
} from "lucide-react";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: ReactNode;
  title?: string;
  className?: string;
  hideNav?: boolean;
  backHref?: string;
}

export function Layout({ children, title, className, hideNav = false }: LayoutProps) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Overview", icon: Home },
    { href: "/emergency", label: "Emergency", icon: Siren },
    { href: "/doctor", label: "Intelligence", icon: Stethoscope },
    { href: "/citizen", label: "Health Metrics", icon: UserCircle },
    { href: "/admin", label: "Public Health", icon: ActivitySquare },
  ];

  if (hideNav) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center w-full">
        {children}
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background w-full">
      {/* Sidebar - Fixed width 240px, Dark Navy */}
      <aside className="w-[240px] bg-[#0f1629] text-white flex-shrink-0 flex flex-col hidden lg:flex shadow-xl z-20">
        <div className="h-16 flex items-center px-6 border-b border-white/10">
          <ShieldPlus className="w-8 h-8 text-primary mr-3" />
          <span className="font-bold text-lg tracking-tight uppercase">National Grid</span>
        </div>
        
        <div className="px-4 py-6 flex-1 overflow-y-auto space-y-2">
          <div className="text-xs font-semibold text-white/50 mb-4 px-2 uppercase tracking-wider">Health Intelligence</div>
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-colors",
                  isActive ? "bg-primary text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
                )}>
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium text-sm">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </div>
        
        <div className="p-4 border-t border-white/10 space-y-2">
          <Link href="/emergency">
            <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer text-white bg-destructive hover:bg-destructive/90 transition-colors shadow-lg">
              <Siren className="w-5 h-5" />
              <span className="font-bold text-sm">Emergency Response</span>
            </div>
          </Link>
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer text-white/70 hover:bg-white/10 transition-colors">
            <Settings className="w-5 h-5" />
            <span className="font-medium text-sm">Settings</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-background relative z-10 overflow-hidden">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-border flex items-center justify-between px-6 flex-shrink-0 z-10 shadow-sm">
          <div className="flex items-center gap-4">
            {title && <h1 className="text-xl font-bold text-foreground">{title}</h1>}
          </div>
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-foreground cursor-pointer hover:bg-secondary/80 transition-colors">
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex items-center gap-3 px-3 py-1.5 rounded-full border border-border hover:bg-secondary transition-colors cursor-pointer">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <UserCircle className="w-5 h-5" />
              </div>
              <span className="text-sm font-medium pr-1">Dr. Sarah</span>
            </div>
          </div>
        </header>

        <div className={cn("flex-1 overflow-y-auto p-6 lg:p-8", className)}>
          {children}
        </div>
      </main>
    </div>
  );
}