import { useParams } from "wouter";
import { Layout } from "@/components/layout";
import { useEmergencyScan } from "@workspace/api-client-react";
import { AlertTriangle, User, Droplet, PhoneCall, Radio, Pill, Activity } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { cn, formatDate } from "@/lib/utils";

export default function EmergencyResult() {
  const { id } = useParams<{ id: string }>();
  const { data, isLoading, isError } = useEmergencyScan(id || "");

  if (isLoading) {
    return (
      <Layout title="Retrieving Emergency Record...">
        <div className="space-y-6 max-w-5xl mx-auto">
          <Skeleton className="h-40 w-full rounded-2xl" />
          <Skeleton className="h-60 rounded-2xl w-full" />
        </div>
      </Layout>
    );
  }

  if (isError || !data) {
    return (
      <Layout title="Error">
        <div className="bg-white rounded-2xl p-10 text-center border border-border mt-10">
          <h2 className="text-2xl font-bold mb-2">Patient Not Found</h2>
          <p className="text-muted-foreground">The ID entered does not match any records.</p>
        </div>
      </Layout>
    );
  }

  const { patient, criticalAlerts, activeMedications } = data;
  const age = new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear();

  return (
    <Layout title={`Emergency Log: Patient #${patient.id}`}>
      <div className="max-w-5xl mx-auto space-y-6">
        
        {criticalAlerts && criticalAlerts.length > 0 && (
          <div className="bg-destructive text-white rounded-xl p-5 shadow-sm flex items-start gap-4">
            <AlertTriangle className="w-8 h-8 flex-shrink-0" />
            <div>
              <h3 className="font-black text-lg uppercase tracking-wider">Critical Medical Alert</h3>
              <ul className="list-disc list-inside mt-2 font-medium">
                {criticalAlerts.map((alert, i) => (
                  <li key={i}>{alert}</li>
                ))}
              </ul>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                <div className="w-24 h-24 rounded-2xl bg-secondary flex items-center justify-center border border-border shrink-0">
                  <User className="w-12 h-12 text-muted-foreground" />
                </div>
                <div className="flex-1 w-full">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-3xl font-extrabold text-foreground">{patient.nameEn || patient.nameAr}</h2>
                      <p className="text-lg text-muted-foreground font-medium mt-1">ID: {patient.nationalId}</p>
                    </div>
                    <div className="text-center shrink-0">
                      <div className="bg-destructive text-white text-2xl font-black px-4 py-2 rounded-xl border border-destructive shadow-sm flex items-center gap-2">
                        <Droplet className="w-5 h-5 fill-current" /> {patient.bloodType}
                      </div>
                      <span className="text-xs text-muted-foreground font-bold mt-2 block uppercase tracking-wider">Blood Type</span>
                    </div>
                  </div>
                  <div className="mt-6 flex flex-wrap gap-8 text-sm font-medium text-foreground bg-secondary/50 p-4 rounded-xl">
                    <div className="flex items-center gap-2"><span className="text-muted-foreground font-bold uppercase text-xs">Age</span> <span className="text-lg">{age}</span></div>
                    <div className="flex items-center gap-2"><span className="text-muted-foreground font-bold uppercase text-xs">Sex</span> <span className="text-lg">{patient.gender === 'male' ? 'Male' : 'Female'}</span></div>
                    <div className="flex items-center gap-2"><span className="text-muted-foreground font-bold uppercase text-xs">DOB</span> <span className="text-lg">{formatDate(patient.dateOfBirth)}</span></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
              <div className="flex items-center gap-3 mb-6 text-foreground">
                <Pill className="w-6 h-6 text-primary" />
                <h3 className="text-xl font-bold">Active Medications</h3>
              </div>
              <div className="space-y-4">
                {activeMedications?.length ? activeMedications.map(med => (
                  <div key={med.id} className="flex justify-between items-center p-4 rounded-xl bg-secondary/30 border border-border">
                    <div>
                      <h4 className="font-bold text-foreground text-lg">{med.name}</h4>
                      <p className="text-sm text-muted-foreground mt-1 font-medium">{med.dosage} • {med.frequency}</p>
                    </div>
                    <div className="text-right text-xs text-muted-foreground">
                      <span className="uppercase tracking-wider font-bold text-[10px]">Prescribed by</span><br/>
                      <span className="font-medium text-sm text-foreground">{med.prescribedBy}</span>
                    </div>
                  </div>
                )) : <p className="text-muted-foreground font-medium">No active medications recorded.</p>}
              </div>
            </div>
            
            <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
              <div className="flex items-center gap-3 mb-6 text-foreground">
                <Activity className="w-6 h-6 text-primary" />
                <h3 className="text-xl font-bold">Chronic Diseases</h3>
              </div>
              <div className="flex flex-wrap gap-3">
                {patient.chronicDiseases?.length ? patient.chronicDiseases.map((d, i) => (
                  <span key={i} className="px-4 py-2 bg-secondary text-foreground font-bold rounded-lg border border-border">
                    {d}
                  </span>
                )) : <p className="text-muted-foreground font-medium">None recorded.</p>}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-6 border border-border shadow-sm">
              <h3 className="font-bold text-lg mb-6 flex items-center gap-2 uppercase tracking-wide text-muted-foreground">
                <PhoneCall className="w-5 h-5" />
                Emergency Contact
              </h3>
              <div className="space-y-5">
                <div>
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">Name</div>
                  <div className="font-bold text-xl">{patient.emergencyContact || "Not provided"}</div>
                </div>
                <div>
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">Phone Number</div>
                  <div className="font-bold text-xl">{patient.emergencyPhone || "Not provided"}</div>
                </div>
              </div>
              <Button className="w-full mt-8 rounded-xl font-bold" size="lg" variant="outline">
                <PhoneCall className="w-5 h-5 mr-2" /> CALL FAMILY
              </Button>
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 shadow-sm">
              <Radio className="w-8 h-8 text-primary mb-4" />
              <h3 className="font-bold text-xl text-primary mb-2">Hospital Dispatch</h3>
              <p className="text-sm text-foreground/80 mb-6 font-medium leading-relaxed">Alert the receiving hospital with the patient's critical data and vital signs before arrival.</p>
              <Button className="w-full bg-primary hover:bg-primary/90 text-white rounded-xl font-bold" size="lg">
                DISPATCH ALERT
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}