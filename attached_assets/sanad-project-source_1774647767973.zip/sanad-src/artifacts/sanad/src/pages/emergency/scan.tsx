import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { ScanLine, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useListPatients } from "@workspace/api-client-react";

export default function EmergencyScan() {
  const [, setLocation] = useLocation();
  const [nationalId, setNationalId] = useState("");
  const { data: patients } = useListPatients();

  const handleScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (nationalId.trim()) {
      setLocation(`/emergency/${nationalId}`);
    }
  };

  return (
    <Layout title="Emergency Scanning">
      <div className="max-w-3xl mx-auto mt-10">
        <div className="bg-white rounded-2xl p-10 border border-border shadow-sm mb-8 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1.5 bg-destructive" />
          
          <div className="w-24 h-24 rounded-full bg-destructive/10 text-destructive flex items-center justify-center mx-auto mb-6">
            <ScanLine className="w-12 h-12 animate-pulse" />
          </div>
          
          <h2 className="text-3xl font-bold text-foreground mb-4">Emergency Patient Scan</h2>
          <p className="text-muted-foreground mb-10 text-lg max-w-xl mx-auto">
            Scan national ID to retrieve critical health records, allergies, and emergency contacts instantly.
          </p>

          <form onSubmit={handleScan} className="max-w-md mx-auto space-y-4">
            <Input
              value={nationalId}
              onChange={(e) => setNationalId(e.target.value)}
              placeholder="Enter National ID (e.g. 1234567890)"
              className="text-center text-xl h-16 rounded-xl border-border focus-visible:ring-destructive"
              autoFocus
            />
            
            <Button 
              type="submit" 
              className="w-full h-16 rounded-xl text-lg font-bold bg-destructive hover:bg-destructive/90 text-white shadow-lg"
            >
              <Search className="w-6 h-6 mr-2" /> Retrieve Emergency Record
            </Button>
          </form>
          
          <div className="mt-8 pt-6 border-t border-border">
            <button className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" onClick={() => setNationalId("1234567890")}>
              Use Demo Patient Record (ID: 1234567890)
            </button>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-border shadow-sm">
          <h3 className="font-bold text-lg mb-4">Recent Emergency Cases</h3>
          <div className="space-y-3">
            {patients?.slice(0, 3).map(p => (
              <div key={p.id} className="flex items-center justify-between p-4 rounded-xl border border-border/50 hover:bg-secondary/50 cursor-pointer transition-colors" onClick={() => setLocation(`/emergency/${p.nationalId}`)}>
                <div>
                  <div className="font-bold text-foreground text-lg">{p.nameEn || p.nameAr}</div>
                  <div className="text-sm text-muted-foreground font-medium mt-1">ID: {p.nationalId}</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-xl text-destructive">{p.bloodType}</div>
                  <div className="text-xs text-muted-foreground uppercase font-bold tracking-wider mt-1">Blood Type</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}