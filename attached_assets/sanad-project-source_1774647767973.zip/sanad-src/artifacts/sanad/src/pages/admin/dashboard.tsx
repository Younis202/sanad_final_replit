import { Layout } from "@/components/layout";
import { useGetDashboardStats, useListPatients } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Users, AlertTriangle, Hospital, ScanFace, type LucideIcon } from "lucide-react";

function StatCard({ title, value, icon: Icon, color, bg }: { title: string; value: number; icon: LucideIcon; color: string; bg: string }) {
  return (
    <div className="bg-white rounded-2xl p-6 border border-border shadow-sm flex items-start gap-4">
      <div className={`${bg} p-3 rounded-xl`}>
        <Icon className={`w-6 h-6 ${color}`} />
      </div>
      <div>
        <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-1">{title}</p>
        <p className="text-3xl font-bold text-foreground">{value.toLocaleString()}</p>
      </div>
    </div>
  );
}

const trendData = [
  { name: 'Mon', scans: 400, alerts: 24 },
  { name: 'Tue', scans: 300, alerts: 13 },
  { name: 'Wed', scans: 200, alerts: 98 },
  { name: 'Thu', scans: 278, alerts: 39 },
  { name: 'Fri', scans: 189, alerts: 48 },
  { name: 'Sat', scans: 239, alerts: 38 },
  { name: 'Sun', scans: 349, alerts: 43 },
];

const riskData = [
  { name: 'Low', count: 4000 },
  { name: 'Moderate', count: 3000 },
  { name: 'High', count: 1200 },
  { name: 'Critical', count: 300 },
];

export default function AdminDashboard() {
  const { data: stats, isLoading } = useGetDashboardStats();
  const { data: patients } = useListPatients();

  if (isLoading) {
    return (
      <Layout title="Command Center">
        <div className="grid grid-cols-4 gap-6 mb-8">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 rounded-2xl" />)}
        </div>
      </Layout>
    );
  }

  if (!stats) return null;

  return (
    <Layout title="National Command Center">
      <div className="max-w-[1400px] mx-auto space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          <StatCard title="Total Patients" value={stats.totalPatients} icon={Users} color="text-blue-600" bg="bg-blue-100" />
          <StatCard title="Emergency Scans (Today)" value={stats.emergencyScansToday} icon={ScanFace} color="text-emerald-600" bg="bg-emerald-100" />
          <StatCard title="Interactions Detected" value={stats.drugInteractionsDetected} icon={AlertTriangle} color="text-orange-600" bg="bg-orange-100" />
          <StatCard title="Hospitals Connected" value={stats.hospitalsConnected} icon={Hospital} color="text-purple-600" bg="bg-purple-100" />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 bg-white rounded-2xl p-8 border border-border shadow-sm">
            <h3 className="text-xl font-bold mb-8 uppercase tracking-wide text-muted-foreground text-sm">System Activity (7 Days)</h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ left: -20, right: 10 }}>
                  <defs>
                    <linearGradient id="colorScans" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fontWeight: 600, fill: 'hsl(var(--muted-foreground))'}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fontWeight: 600, fill: 'hsl(var(--muted-foreground))'}} />
                  <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid hsl(var(--border))', fontWeight: 'bold', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                  <Area type="monotone" dataKey="scans" stroke="hsl(var(--primary))" strokeWidth={4} fillOpacity={1} fill="url(#colorScans)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
            <h3 className="text-xl font-bold mb-8 uppercase tracking-wide text-muted-foreground text-sm">Population Risk Distribution</h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskData} layout="vertical" margin={{top: 0, right: 0, left: 20, bottom: 0}}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fontWeight: 'bold', fill: 'hsl(var(--foreground))'}} />
                  <Tooltip cursor={{fill: 'hsl(var(--secondary))'}} contentStyle={{ borderRadius: '12px', fontWeight: 'bold' }} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={30} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-border shadow-sm overflow-hidden">
          <div className="p-6 border-b border-border bg-secondary/30">
            <h3 className="font-bold text-lg uppercase tracking-wide text-muted-foreground text-sm">High Risk Patients Directory</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-secondary/10 text-muted-foreground text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-4 font-bold">Patient Name</th>
                  <th className="px-6 py-4 font-bold">National ID</th>
                  <th className="px-6 py-4 font-bold">Risk Level</th>
                  <th className="px-6 py-4 font-bold">Region</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {patients?.slice(0,5).map((p, i) => (
                  <tr key={p.id} className="hover:bg-secondary/20 transition-colors">
                    <td className="px-6 py-5 font-bold text-foreground">{p.nameEn || p.nameAr}</td>
                    <td className="px-6 py-5 text-muted-foreground font-medium">{p.nationalId}</td>
                    <td className="px-6 py-5">
                      <span className="bg-destructive/10 text-destructive px-3 py-1 rounded-md font-bold text-xs uppercase tracking-wider">High Risk</span>
                    </td>
                    <td className="px-6 py-5 text-muted-foreground font-medium">Riyadh</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </Layout>
  );
}