import { Layout } from "@/components/layout";
import { useGetDoctorPatientView } from "@workspace/api-client-react";
import { Shield, FileText, Bell, HeartPulse, Download, Activity, Syringe, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function CitizenDashboard() {
  const { data, isLoading } = useGetDoctorPatientView("1234567890");

  if (isLoading) {
    return (
      <Layout title="Patient Log">
        <div className="max-w-5xl mx-auto space-y-6">
          <Skeleton className="h-48 w-full rounded-2xl" />
          <Skeleton className="h-64 w-full rounded-2xl" />
        </div>
      </Layout>
    );
  }

  if (!data) return null;
  const { patient, medications, labResults } = data;

  return (
    <Layout title="Health Metrics & Patient Log">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Health Card Header */}
        <div className="bg-white rounded-2xl p-8 border border-border shadow-sm flex flex-col md:flex-row gap-8 items-center md:items-start justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -mr-10 -mt-10" />
          
          <div className="flex items-center gap-6 relative z-10">
            <div className="w-24 h-24 rounded-2xl bg-primary text-white flex items-center justify-center text-4xl font-black shadow-lg shadow-primary/20">
              {patient.nameEn?.[0] || 'S'}
            </div>
            <div>
              <h2 className="text-3xl font-black text-foreground">{patient.nameEn || patient.nameAr}</h2>
              <p className="text-muted-foreground mt-1 font-medium text-lg">National ID: {patient.nationalId}</p>
              <div className="flex gap-4 mt-4 text-sm">
                <span className="bg-secondary px-4 py-1.5 rounded-lg font-bold text-foreground border border-border">Blood: <span className="text-destructive">{patient.bloodType}</span></span>
                <span className="bg-secondary px-4 py-1.5 rounded-lg font-bold text-foreground border border-border">DOB: {new Date(patient.dateOfBirth).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
          <Button className="shrink-0 rounded-xl shadow-lg relative z-10 h-14 px-6 text-base font-bold" size="lg">
            <Download className="w-5 h-5 mr-2" /> Download Health Card
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="md:col-span-2 space-y-8">
            <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
              <h3 className="font-bold text-xl mb-6 flex items-center gap-2"><Activity className="w-6 h-6 text-primary"/> Vital Signs</h3>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <MetricCard label="Heart Rate" value="112" unit="BPM" status="HIGH" alert />
                <MetricCard label="Blood Pressure" value="142/88" unit="mmHg" status="ALERT" alert />
                <MetricCard label="Blood Oxygen" value="94" unit="%" status="STABLE" />
                <MetricCard label="Temperature" value="37.2" unit="°C" status="NORMAL" />
              </div>

              <div className="h-32 w-full bg-secondary/30 rounded-xl border border-border relative overflow-hidden flex items-center justify-center">
                {/* Mock ECG Waveform */}
                <svg className="w-full h-full opacity-60" preserveAspectRatio="none" viewBox="0 0 500 100">
                  <polyline 
                    fill="none" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth="3"
                    points="0,50 50,50 60,30 70,80 80,20 90,50 150,50 160,30 170,80 180,20 190,50 250,50 260,30 270,80 280,20 290,50 350,50 360,30 370,80 380,20 390,50 450,50 460,30 470,80 480,20 490,50 500,50" 
                  />
                </svg>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-xl">Active Prescriptions</h3>
                <Button variant="outline" size="sm" className="rounded-lg">Refill Request</Button>
              </div>
              <div className="space-y-4">
                {medications?.map(m => (
                  <div key={m.id} className="flex justify-between items-center p-5 bg-secondary/40 rounded-xl border border-border transition-all hover:bg-secondary">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-primary">
                        <PillIcon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="font-bold text-lg">{m.name}</div>
                        <div className="text-muted-foreground font-medium">{m.dosage} - {m.frequency}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-emerald-600 bg-emerald-100 px-3 py-1 rounded-full uppercase tracking-wider mb-1 inline-block">Active</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-gradient-to-br from-primary to-blue-800 rounded-2xl p-8 text-white shadow-xl flex flex-col items-center text-center relative">
              <h3 className="font-bold text-lg mb-6 text-blue-100 uppercase tracking-widest">Health Score</h3>
              <div className="text-7xl font-black mb-2 tracking-tighter">72<span className="text-3xl text-white/50">/100</span></div>
              <div className="bg-white/20 px-6 py-2 rounded-full text-sm font-bold tracking-widest uppercase backdrop-blur-md mt-4">MODERATE</div>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-border shadow-sm">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2 uppercase tracking-wider text-muted-foreground text-sm"><Bell className="w-5 h-5 text-warning"/> System Alerts</h3>
              <div className="bg-warning/10 text-warning-foreground p-5 rounded-xl border border-warning/20">
                <h4 className="font-bold text-base mb-1">Upcoming Appointment</h4>
                <p className="text-sm font-medium">Cardiology checkup in 3 days at General Hospital.</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-border shadow-sm">
              <h3 className="font-bold text-lg mb-4 uppercase tracking-wider text-muted-foreground text-sm">Quick Actions</h3>
              <div className="space-y-3">
                <ActionButton icon={FileText} label="View Lab Results" />
                <ActionButton icon={Syringe} label="Vaccination Record" />
                <ActionButton icon={Calendar} label="Book Appointment" />
              </div>
            </div>
          </div>

        </div>
      </div>
    </Layout>
  );
}

function MetricCard({ label, value, unit, status, alert }: any) {
  return (
    <div className={cn("p-5 rounded-xl border text-center", alert ? "bg-destructive/5 border-destructive/20" : "bg-secondary/30 border-border")}>
      <div className="text-sm text-muted-foreground font-bold uppercase tracking-wider mb-2">{label}</div>
      <div className={cn("text-3xl font-black mb-1", alert ? "text-destructive" : "text-foreground")}>
        {value}<span className="text-sm font-bold text-muted-foreground ml-1">{unit}</span>
      </div>
      {status && <div className={cn("text-xs font-black uppercase tracking-wider", alert ? "text-destructive" : "text-emerald-600")}>{status}</div>}
    </div>
  );
}

function ActionButton({ icon: Icon, label }: any) {
  return (
    <button className="w-full flex items-center gap-3 p-4 rounded-xl border border-border hover:bg-secondary hover:border-primary/30 transition-all text-left group">
      <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
        <Icon className="w-5 h-5" />
      </div>
      <span className="font-bold text-foreground">{label}</span>
    </button>
  )
}

function PillIcon(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/></svg>;
}