import { useState } from "react";
import { useParams } from "wouter";
import { Layout } from "@/components/layout";
import { useGetDoctorPatientView } from "@workspace/api-client-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';
import { 
  AlertOctagon, Activity, ShieldAlert, X, ChevronRight, CheckCircle2, User, UserCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn, formatDate } from "@/lib/utils";

const riskTrendData = [
  { month: 'Jan', risk: 45 },
  { month: 'Feb', risk: 52 },
  { month: 'Mar', risk: 48 },
  { month: 'Apr', risk: 65 },
  { month: 'May', risk: 78 },
  { month: 'Jun', risk: 82 },
];

export default function DoctorDashboard() {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [dismissBanner, setDismissBanner] = useState(false);
  
  const { data, isLoading } = useGetDoctorPatientView(id || "");
  
  if (isLoading) {
    return (
      <Layout title="Loading Intelligence...">
        <div className="space-y-6">
          <Skeleton className="h-24 w-full rounded-2xl" />
          <div className="grid grid-cols-3 gap-6">
            <Skeleton className="col-span-2 h-96 rounded-2xl" />
            <Skeleton className="h-96 rounded-2xl" />
          </div>
        </div>
      </Layout>
    );
  }

  if (!data) return <Layout title="Not Found"><div className="p-10 text-center font-bold text-xl">Patient record not found.</div></Layout>;

  const { patient, medications, labResults, visits, riskScore, drugInteractions } = data;
  const hasCriticalAlert = drugInteractions && drugInteractions.some(d => d.severity === 'critical');

  return (
    <Layout title={`Patient Record: ${patient.nameEn || patient.nameAr}`}>
      <div className="max-w-[1400px] mx-auto space-y-6">
        
        {hasCriticalAlert && !dismissBanner && (
          <div className="bg-destructive text-white rounded-xl p-4 shadow-sm flex items-center justify-between relative overflow-hidden">
            <div className="absolute inset-0 bg-white/10 w-1/2 skew-x-12 -ml-10" />
            <div className="flex items-center gap-3 relative z-10">
              <AlertOctagon className="w-6 h-6 flex-shrink-0" />
              <span className="font-bold uppercase tracking-wider text-sm md:text-base">
                CRITICAL DRUG-DRUG INTERACTION ALERT: Warfarin and Ibuprofen conflict detected for Patient #{patient.id}. Immediate review required.
              </span>
            </div>
            <div className="flex items-center gap-3 relative z-10 shrink-0">
              <Button variant="outline" size="sm" className="bg-white text-destructive hover:bg-white/90 border-transparent font-bold">
                [RESOLVE CONFLICT]
              </Button>
              <button onClick={() => setDismissBanner(true)} className="p-1 hover:bg-white/20 rounded-lg transition-colors"><X className="w-5 h-5" /></button>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex border-b border-border bg-white rounded-t-2xl px-4 pt-4 shadow-sm pb-0">
          {["dashboard", "analytics", "reports", "audit"].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-6 py-4 font-bold text-sm uppercase tracking-wide transition-colors border-b-2 mb-[-1px]",
                activeTab === tab ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
              )}
            >
              {tab}
            </button>
          ))}
        </div>

        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            
            {/* Left Main Column */}
            <div className="xl:col-span-2 space-y-6">
              {/* AI Predictive Analysis Card */}
              <div className="bg-[#1e40af] rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
                <div className="absolute top-[-50%] right-[-10%] w-[50%] h-[200%] bg-white/5 rotate-12 blur-2xl pointer-events-none" />
                <div className="flex justify-between items-start mb-6 relative z-10">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Activity className="w-5 h-5 text-blue-300" />
                      <h3 className="text-xl font-bold">AI Predictive Analysis</h3>
                    </div>
                    <p className="text-blue-200 text-sm font-medium">6-month health trajectory and risk forecast</p>
                  </div>
                  <div className="bg-white/10 px-4 py-2 rounded-lg backdrop-blur-sm border border-white/20">
                    <span className="text-sm font-bold text-blue-100 uppercase tracking-wider">Trend: Escalating</span>
                  </div>
                </div>
                <div className="h-64 w-full relative z-10">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={riskTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
                      <XAxis dataKey="month" stroke="rgba(255,255,255,0.5)" tick={{fill: 'rgba(255,255,255,0.7)', fontSize: 12, fontWeight: 600}} axisLine={false} tickLine={false} />
                      <YAxis stroke="rgba(255,255,255,0.5)" tick={{fill: 'rgba(255,255,255,0.7)', fontSize: 12, fontWeight: 600}} axisLine={false} tickLine={false} />
                      <RechartsTooltip 
                        contentStyle={{ backgroundColor: '#0f1629', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontWeight: 'bold' }}
                        itemStyle={{ color: '#fff' }}
                      />
                      <Line type="monotone" dataKey="risk" stroke="#93c5fd" strokeWidth={4} dot={{r: 6, fill: '#1e40af', strokeWidth: 3, stroke: '#93c5fd'}} activeDot={{r: 8}} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Patient Summary */}
              <div className="bg-white rounded-2xl p-6 border border-border shadow-sm flex flex-wrap gap-8 items-center justify-between">
                 <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center"><UserCircle className="w-8 h-8 text-muted-foreground" /></div>
                    <div>
                      <h2 className="text-xl font-bold">{patient.nameEn || patient.nameAr}</h2>
                      <p className="text-sm text-muted-foreground font-medium">ID: {patient.nationalId}</p>
                    </div>
                 </div>
                 <div className="flex gap-8 text-sm">
                    <div><div className="text-muted-foreground font-bold uppercase tracking-wider mb-1 text-xs">DOB</div><div className="font-bold text-lg">{formatDate(patient.dateOfBirth)}</div></div>
                    <div><div className="text-muted-foreground font-bold uppercase tracking-wider mb-1 text-xs">Blood</div><div className="font-bold text-lg text-destructive">{patient.bloodType}</div></div>
                 </div>
              </div>

              {/* Active Medications & Labs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-2xl p-6 border border-border shadow-sm">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-lg">Active Medications</h3>
                  </div>
                  <div className="space-y-4">
                    {medications?.filter(m => m.isActive).map(med => (
                      <div key={med.id} className="border-l-4 border-l-primary bg-secondary/30 rounded-r-xl p-4">
                        <div className="font-bold text-foreground">{med.name}</div>
                        <div className="text-sm text-muted-foreground mt-1 font-medium">{med.dosage} - {med.frequency}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 border border-border shadow-sm">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-lg">Recent Diagnostics</h3>
                  </div>
                  <div className="space-y-4">
                    {labResults?.slice(0,3).map(lab => (
                      <div key={lab.id} className="flex justify-between items-center p-3 rounded-xl hover:bg-secondary transition-colors">
                        <div>
                          <div className="font-bold text-foreground">{lab.testName}</div>
                          <div className="text-xs text-muted-foreground font-medium">{formatDate(lab.testedAt)}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">{lab.value} <span className="text-xs text-muted-foreground">{lab.unit}</span></div>
                          <span className={cn(
                            "text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider",
                            lab.status === 'normal' ? "bg-green-100 text-green-700" :
                            lab.status === 'high' || lab.status === 'low' ? "bg-orange-100 text-orange-700" : "bg-red-100 text-red-700"
                          )}>
                            {lab.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side Column */}
            <div className="space-y-6">
              {/* Risk Score */}
              <div className="bg-white rounded-2xl p-6 border border-border shadow-sm flex flex-col items-center text-center relative overflow-hidden">
                <h3 className="font-bold text-lg w-full text-left mb-6 uppercase tracking-wide text-muted-foreground">Health Risk Score</h3>
                <div className="relative w-48 h-48 flex items-center justify-center mb-6">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="var(--color-secondary)"
                      strokeWidth="2.5"
                    />
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="var(--color-destructive)"
                      strokeWidth="2.5"
                      strokeDasharray={`${riskScore?.overallScore || 82}, 100`}
                      className="drop-shadow-md"
                    />
                  </svg>
                  <div className="absolute text-center flex flex-col items-center">
                    <div className="text-5xl font-black text-foreground mb-1">{riskScore?.overallScore || 82}</div>
                    <div className="text-xs font-bold text-destructive bg-destructive/10 px-2 py-1 rounded">HIGH RISK</div>
                  </div>
                </div>
                <div className="w-full bg-secondary/50 rounded-xl p-4 text-sm text-left">
                  <div className="flex items-start gap-2 text-destructive mb-2">
                    <ShieldAlert className="w-4 h-4 mt-0.5" />
                    <span className="font-bold">Primary Factor:</span>
                  </div>
                  <p className="text-muted-foreground font-medium pl-6">Drug interaction combined with recent elevated blood pressure readings.</p>
                </div>
              </div>

              {/* Active Care Team */}
              <div className="bg-white rounded-2xl p-6 border border-border shadow-sm">
                <h3 className="font-bold text-lg mb-6 uppercase tracking-wide text-muted-foreground">Active Care Team</h3>
                <div className="space-y-4">
                  {[
                    { name: 'Dr. Sarah Jenkins', role: 'Primary Care', initial: 'S' },
                    { name: 'Dr. Ahmed Al-Fayed', role: 'Cardiology', initial: 'A' },
                    { name: 'Nurse Emma Stone', role: 'Care Coordinator', initial: 'E' }
                  ].map((member, i) => (
                    <div key={i} className="flex items-center gap-4 p-3 hover:bg-secondary rounded-xl transition-colors cursor-pointer border border-transparent hover:border-border">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg border border-primary/20">
                        {member.initial}
                      </div>
                      <div>
                        <div className="font-bold text-foreground">{member.name}</div>
                        <div className="text-sm text-muted-foreground font-medium">{member.role}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-6 rounded-xl font-bold">Manage Care Team</Button>
              </div>
            </div>
            
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="bg-white rounded-2xl p-8 border border-border shadow-sm text-center">
            <h2 className="text-2xl font-bold mb-4">Detailed Analytics</h2>
            <p className="text-muted-foreground">Full historical metrics and deep AI insights will be displayed here.</p>
          </div>
        )}

      </div>
    </Layout>
  );
}