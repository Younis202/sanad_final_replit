import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { Stethoscope, Search, FileText } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useListPatients } from "@workspace/api-client-react";

export default function DoctorSearch() {
  const [, setLocation] = useLocation();
  const [nationalId, setNationalId] = useState("");
  const { data: patients } = useListPatients();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (nationalId.trim()) {
      setLocation(`/doctor/${nationalId}`);
    }
  };

  return (
    <Layout title="Intelligence Search">
      <div className="max-w-5xl mx-auto space-y-8">
        <div className="flex items-center gap-3 text-muted-foreground mb-4 bg-secondary inline-flex px-4 py-2 rounded-lg">
          <Stethoscope className="w-5 h-5" />
          <h2 className="text-sm font-bold uppercase tracking-wider">Physician View: Dr. Sarah Jenkins</h2>
        </div>

        <div className="bg-white rounded-2xl p-10 border border-border shadow-sm flex gap-10 items-center">
          <div className="flex-1">
            <h3 className="text-3xl font-black mb-3">Patient Intelligence Search</h3>
            <p className="text-muted-foreground text-lg mb-8 max-w-xl">Enter patient National ID to pull complete medical history and predictive AI risk analysis.</p>
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-4 max-w-2xl">
              <Input
                value={nationalId}
                onChange={(e) => setNationalId(e.target.value)}
                placeholder="National ID (e.g. 1234567890)"
                className="text-lg h-16 flex-1 rounded-xl"
              />
              <Button type="submit" className="h-16 px-10 rounded-xl text-lg font-bold shadow-lg shadow-primary/20">
                <Search className="w-5 h-5 mr-2" /> Search
              </Button>
            </form>
          </div>
          <div className="hidden md:flex w-56 h-56 bg-primary/5 rounded-3xl items-center justify-center border border-primary/10">
             <FileText className="w-24 h-24 text-primary/40" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-border shadow-sm overflow-hidden">
          <div className="p-6 border-b border-border bg-secondary/30">
            <h3 className="font-bold text-lg">Recently Viewed Patients</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-secondary/10 text-muted-foreground text-sm uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-4 font-bold">Patient Name</th>
                  <th className="px-6 py-4 font-bold">National ID</th>
                  <th className="px-6 py-4 font-bold">DOB</th>
                  <th className="px-6 py-4 font-bold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {patients?.map(p => (
                  <tr key={p.id} className="hover:bg-secondary/20 transition-colors group">
                    <td className="px-6 py-5 font-bold text-foreground text-lg">{p.nameEn || p.nameAr}</td>
                    <td className="px-6 py-5 text-muted-foreground font-medium">{p.nationalId}</td>
                    <td className="px-6 py-5 text-muted-foreground font-medium">{new Date(p.dateOfBirth).toLocaleDateString()}</td>
                    <td className="px-6 py-5 text-right">
                      <Button className="rounded-lg opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => setLocation(`/doctor/${p.nationalId}`)}>
                        View Record
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
}