import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { ShieldPlus, Siren, Stethoscope, UserCircle, ActivitySquare, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <Layout hideNav>
      <div className="w-full max-w-6xl mx-auto px-6 py-12 md:py-24 flex flex-col items-center">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
            <ShieldPlus className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-foreground tracking-tight uppercase">
            SANAD Health
          </h1>
        </div>
        
        <p className="text-xl text-muted-foreground text-center max-w-2xl mb-16">
          National Health Intelligence System. Select a specialized portal to securely access the national grid.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
          <PortalCard 
            href="/emergency" 
            title="Emergency Portal" 
            description="Rapid access for paramedics. Scan IDs to retrieve critical patient medical data, allergies, and blood types instantly."
            icon={Siren}
          />
          <PortalCard 
            href="/doctor" 
            title="Doctor Portal" 
            description="Comprehensive patient health records, AI-powered predictive diagnostics, and active medication tracking."
            icon={Stethoscope}
          />
          <PortalCard 
            href="/citizen" 
            title="Citizen Portal" 
            description="Access your personal health log, vitals, active medications, and manage your health score."
            icon={UserCircle}
          />
          <PortalCard 
            href="/admin" 
            title="Admin Dashboard" 
            description="National level metrics, real-time alerts, and predictive health trend analytics."
            icon={ActivitySquare}
          />
        </div>
      </div>
    </Layout>
  );
}

function PortalCard({ href, title, description, icon: Icon }: any) {
  return (
    <Link href={href}>
      <div className="group bg-white rounded-2xl p-8 border border-border shadow-sm hover:shadow-xl hover:border-primary transition-all duration-300 cursor-pointer h-full flex flex-col relative overflow-hidden">
        <div className="w-14 h-14 rounded-xl bg-secondary text-primary flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
          <Icon className="w-7 h-7" />
        </div>
        <h2 className="text-2xl font-bold mb-3 text-foreground">{title}</h2>
        <p className="text-muted-foreground flex-1 leading-relaxed text-lg">{description}</p>
        <div className="mt-8 flex items-center font-bold text-primary opacity-80 group-hover:opacity-100 group-hover:translate-x-2 transition-all">
          Enter Portal <ArrowRight className="w-5 h-5 ml-2" />
        </div>
      </div>
    </Link>
  );
}